#include <header.h>

void setup() {
  EEPROM.begin(512); // Initialize EEPROM with 512 bytes
  Serial.begin(115200);
  setup_wifi();
  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);
  loadSettingsFromEEPROM();
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();

  // Emergency stop handling
  if (emergencyStop) {
    stopSteppers(); // Smoothly stop all
    wasEmergencyStop = true;
  } else {
    // Emergency stop was just released
    if (previousEmergencyStop && wasEmergencyStop) {
      wasEmergencyStop = false;
      resumeAfterEmergencyStop();
    }
  }

  // Always track previous state
  previousEmergencyStop = emergencyStop;


  switch (Mode) {
    case MANUAL:
      if (run && !manualTriggered) {
        manualTriggered = true;
        moveAllJoints();
      }

      if (manualTriggered && jointsAreAtTarget()) {
        manualTriggered = false;
        run = false; // Reset run to false after manual movement
      }
      break;
    case SEQUENCE:
      runJointSequence();
      updateSequence();
      if (!jointSequenceInProgress && sequenceStep == 0) {
        msg1 = "Sequence completed";
        client.publish("robot/status", msg1.c_str());
      }
      break;
    case AUTO:
      if (autoStepMode == STEP_ONE_BY_ONE) {
        runAutoSequence();
        updateAutoSequence();
      } else if (autoStepMode == STEP_ALL_AT_ONCE) {
        runAutoMode();
      }
      break;
    case HOME:
      Home();
      break;
  }

  updateAllSteppers(); // Update all steppers in the loop
  
  if (millis() - lastMsg > 2000) {
    lastMsg = millis();
    String msg = "Alive";
    Serial.print("Publish message: ");
    Serial.println(msg);
    client.publish("robot/status", msg.c_str());
  }
}
