#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <stepper.h>
#include <EEPROM.h>

unsigned long lastMsg = 0;
enum ControlMode {
  MANUAL = 0,
  SEQUENCE = 1,
  AUTO = 2,
  HOME = 3
};
ControlMode Mode = MANUAL;

enum AutoStepMode {
  STEP_ALL_AT_ONCE = 0,
  STEP_ONE_BY_ONE = 1,
};
AutoStepMode autoStepMode = STEP_ONE_BY_ONE; 

int mode = 0;
int auto_Mode = 0;

String msg1;
static bool wasEmergencyStop = false;
bool previousEmergencyStop = false;

bool waypointSettingUpdated = false;

// Wi-Fi credentials
const char* ssid = "Archery Wifi_2.4G_R_EXT";
const char* password = "LDB919702";

// MQTT Broker settings
const char* mqtt_server = "192.168.0.101";  // IP of the Node-RED Docker host
const int mqtt_port = 1883;
const char* topic = "/test/msg";  // This topic includes spaces

WiFiClient espClient;
PubSubClient client(espClient);

void saveMaxSpeedSettingToEEPROM() {
  EEPROM.put(0, maxSpeed);
  Serial.println("Max Speed setting saved to EEPROM.");
  EEPROM.commit();
}

void saveAccelerationSettingToEEPROM() {
  EEPROM.put(4, Acceleration);
  Serial.println("Acceleration setting saved to EEPROM.");
  EEPROM.commit();
}

void setup_wifi() {
  delay(10);
  Serial.println("Connecting to WiFi...");
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi connected!");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());
}

void callback(char* topic, byte* payload, unsigned int length) {
  String jsonString;
  for (unsigned int i = 0; i < length; i++) {
    jsonString += (char)payload[i];
  }

  DynamicJsonDocument doc(256);
  DeserializationError error = deserializeJson(doc, jsonString);

  if (error) {
    Serial.print("JSON Error: ");
    Serial.println(error.c_str());
    return;
  }

  Serial.println("=== Joint Angle Update ===");
  
  if (doc.containsKey("Robot Control/Joint 1 Angle")) {
    joint1 = doc["Robot Control/Joint 1 Angle"].as<float>();
    Serial.print("Joint 1 Angle: "); Serial.println(joint1);
  }
  if (doc.containsKey("Robot Control/Joint 2 Angle")) {
    joint2 = doc["Robot Control/Joint 2 Angle"].as<float>();
    Serial.print("Joint 2 Angle: "); Serial.println(joint2);
  }
  if (doc.containsKey("Robot Control/Joint 3 Angle")) {
    joint3 = doc["Robot Control/Joint 3 Angle"].as<float>();
    Serial.print("Joint 3 Angle: "); Serial.println(joint3);
  }
  if (doc.containsKey("Robot Control/Joint 4 Angle")) {
    joint4 = doc["Robot Control/Joint 4 Angle"].as<float>();
    Serial.print("Joint 4 Angle: "); Serial.println(joint4);
  }
  if (doc.containsKey("Robot Control/Joint 5 Angle")) {
    joint5 = doc["Robot Control/Joint 5 Angle"].as<float>();
    Serial.print("Joint 5 Angle: "); Serial.println(joint5);
  }
  if (doc.containsKey("Robot Control/Max Speed")) {
    maxSpeed = doc["Robot Control/Max Speed"].as<float>();
    updateMaxSpeed();
    safeSettingUpdate(); // Update settings if needed
    Serial.print("Max Speed: "); Serial.println(maxSpeed);
    saveMaxSpeedSettingToEEPROM(); // Save to EEPROM
  }
  if (doc.containsKey("Robot Control/Acceleration")) {
    Acceleration = doc["Robot Control/Acceleration"].as<float>();
    updateAcceleration();
    safeSettingUpdate(); // Update settings if needed
    Serial.print("Acceleration: "); Serial.println(Acceleration);
    saveAccelerationSettingToEEPROM(); // Save to EEPROM
  }
  if (doc.containsKey("Robot Control/Run")) {
    run = doc["Robot Control/Run"].as<bool>();
    Serial.print("Run: "); Serial.println(run);
  }
  if (doc.containsKey("Robot Control/Emergency Stop")) {
    emergencyStop = doc["Robot Control/Emergency Stop"].as<bool>();
    Serial.print("Emergency Stop: "); Serial.println(emergencyStop);
  }
  if (doc.containsKey("Robot Control/Mode")) {
    mode = doc["Robot Control/Mode"].as<int>();
    Serial.print("Mode: "); Serial.println(mode);
    if (mode == 0) {
      Mode = MANUAL;
    } else if (mode == 1) {
      Mode = SEQUENCE;
    } else if (mode == 2) {
      Mode = AUTO;
    } else if (mode == 3) {
      Mode = HOME;
    }
  }
  if (doc.containsKey("Robot Control/Auto Mode")) {
    auto_Mode = doc["Robot Control/Auto Mode"].as<int>();
    Serial.print("Auto Mode: "); Serial.println(auto_Mode);
    if (auto_Mode == 0) {
      autoStepMode = STEP_ALL_AT_ONCE;
    } else if (auto_Mode == 1) {
      autoStepMode = STEP_ONE_BY_ONE;
    }
  }
  if (doc.containsKey("Robot Control/WaypointSettingA")) {
    WaypointSettingA = doc["Robot Control/WaypointSettingA"].as<bool>();
    Serial.print("WaypointSettingA: "); Serial.println(WaypointSettingA);
    waypointSettingUpdated = true;
  }
  if (doc.containsKey("Robot Control/WaypointSettingB")) {
    WaypointSettingB = doc["Robot Control/WaypointSettingB"].as<bool>();
    Serial.print("WaypointSettingB: "); Serial.println(WaypointSettingB);
    waypointSettingUpdated = true;
  }
  
  if (waypointSettingUpdated){
    updateWaypointSettings(); // Update waypoint settings if needed
    waypointSettingUpdated = false;
  }
}


void reconnect() {
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    if (client.connect("ESP32Client")) {
      Serial.println("connected");
      client.subscribe(topic);
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" retrying in 5 seconds");
      delay(5000);
    }
  }
}

void resumeAfterEmergencyStop() {
  if (Mode == MANUAL && manualTriggered) {
    moveAllJoints(); // Re-issue the move command to target positions
    msg1 = "Manual resumed after emergency";
  }
  else if (Mode == SEQUENCE && jointSequenceInProgress) {
    msg1 = "Sequence resumed after emergency";
  }
  else if (Mode == AUTO) {
    msg1 = "Auto resumed after emergency";
  }
  client.publish("robot/status", msg1.c_str());
}

void loadSettingsFromEEPROM() {
  EEPROM.get(0, maxSpeed);
  updateMaxSpeed();
  Serial.println(maxSpeed);
  EEPROM.get(4, Acceleration);
  updateAcceleration();
  Serial.println(Acceleration);
  Serial.println("Settings loaded from EEPROM.");
}