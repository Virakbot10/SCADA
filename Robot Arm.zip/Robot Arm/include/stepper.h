#include <AccelStepper.h>
#include <cmath>

#define DIR_PIN_J1   14
#define STEP_PIN_J1  27

#define DIR_PIN_J2   26
#define STEP_PIN_J2  25

#define DIR_PIN_J3   33
#define STEP_PIN_J3  32

#define DIR_PIN_J4   18
#define STEP_PIN_J4  19

#define DIR_PIN_J5   5
#define STEP_PIN_J5  17

#define DIR_PIN_J6   16
#define STEP_PIN_J6  4

AccelStepper stepper1(AccelStepper::DRIVER, STEP_PIN_J1, DIR_PIN_J1);
AccelStepper stepper2(AccelStepper::DRIVER, STEP_PIN_J2, DIR_PIN_J2);
AccelStepper stepper3(AccelStepper::DRIVER, STEP_PIN_J3, DIR_PIN_J3);
AccelStepper stepper4(AccelStepper::DRIVER, STEP_PIN_J4, DIR_PIN_J4);
AccelStepper stepper5(AccelStepper::DRIVER, STEP_PIN_J5, DIR_PIN_J5);
AccelStepper stepper6(AccelStepper::DRIVER, STEP_PIN_J6, DIR_PIN_J6);

float joint1 = 0.0;
float joint2 = 0.0;
float joint3 = 0.0;
float joint4 = 0.0;
float joint5 = 0.0;
float joint6 = 0.0;

const float microStep = 1;

const float degreesPerStep = 1.8 / microStep; // Assuming 1.8 degrees per step for the stepper motors
const float J1GearRatio = 10.533;
const float J2GearRatio = 5.455;
const float J3GearRatio = 21.59;
const float J4GearRatio = 1;
const float J5GearRatio = 4.667;

float maxSpeed, Acceleration;
bool run = false;
bool manualTriggered = false;
bool emergencyStop = false;
bool jointSequenceInProgress = false;
bool autoTriggered = false;
bool autoModeInProgress = false;
bool autoSequenceInProgress = false;
bool autoSequenceWaiting = false;
int autoSequenceStep = 0;
int sequenceStep = 0;
bool sequenceWaiting = false;

struct Waypoint {
    float j1, j2, j3, j4, j5;
  };

Waypoint waypointA = {0, 0, 0, 0, 0};
Waypoint waypointB = {0, 0, 0, 0, 0};
bool movingToA = true;

bool WaypointSettingA = false;
bool WaypointSettingB = false;

void updateMaxSpeed() {
    stepper1.setMaxSpeed(maxSpeed);
    stepper2.setMaxSpeed(maxSpeed);
    stepper3.setMaxSpeed(maxSpeed);
    stepper4.setMaxSpeed(maxSpeed);
    stepper5.setMaxSpeed(maxSpeed);
    stepper6.setMaxSpeed(maxSpeed);
}

void updateAcceleration() {
    stepper1.setAcceleration(Acceleration);
    stepper2.setAcceleration(Acceleration);
    stepper3.setAcceleration(Acceleration);
    stepper4.setAcceleration(Acceleration);
    stepper5.setAcceleration(Acceleration);
    stepper6.setAcceleration(Acceleration);
}

void moveAllJoints() {
    stepper1.moveTo(lround((joint1 * J1GearRatio) / degreesPerStep)); // Convert degrees to steps
    stepper2.moveTo(lround((joint2 * J2GearRatio) / degreesPerStep)); // Convert degrees to steps
    stepper3.moveTo(lround((joint3 * J3GearRatio) / degreesPerStep)); // Convert degrees to steps
    stepper4.moveTo(lround((joint4 * J4GearRatio) / degreesPerStep)); // Convert degrees to steps
    stepper5.moveTo(lround((joint5 * J5GearRatio) / degreesPerStep)); // Convert degrees to steps
    stepper6.moveTo(lround((joint1 * J5GearRatio) / degreesPerStep)); // Convert degrees to steps
}

void updateAllSteppers() {
    stepper1.run();
    stepper2.run();
    stepper3.run();
    stepper4.run();
    stepper5.run();
    stepper6.run();
}

void stopSteppers() {
    stepper1.stop();
    stepper2.stop();
    stepper3.stop();
    stepper4.stop();
    stepper5.stop();
    stepper6.stop();
}

bool jointsAreAtTarget() {
    if (stepper1.distanceToGo() == 0 && stepper2.distanceToGo() == 0 &&
        stepper3.distanceToGo() == 0 && stepper4.distanceToGo() == 0 &&
        stepper5.distanceToGo() == 0 && stepper6.distanceToGo() == 0) {
        return true;
    }
    return false;
}

void runJointSequence() {
    if (!run || jointSequenceInProgress) return;
    
    jointSequenceInProgress = true;
    sequenceStep = 1;
    sequenceWaiting = false;
    run = false;
  }
  
void updateSequence() {
    if (!jointSequenceInProgress) return;

    switch (sequenceStep) {
        case 1:
            if (!sequenceWaiting) {
                stepper1.moveTo(joint1);
                stepper6.moveTo(joint1); // Assuming J6 is controlled by J1
                sequenceWaiting = true;
            }
            if (!stepper1.isRunning() && !stepper6.isRunning()) {
                sequenceStep++;
                sequenceWaiting = false;
            }
            break;

        case 2:
            if (!sequenceWaiting) {
                stepper2.moveTo(joint2);
                sequenceWaiting = true;
            }
            if (!stepper2.isRunning()) {
                sequenceStep++;
                sequenceWaiting = false;
            }
            break;

        case 3:
            if (!sequenceWaiting) {
                stepper3.moveTo(joint3);
                sequenceWaiting = true;
            }
            if (!stepper3.isRunning()) {
                sequenceStep++;
                sequenceWaiting = false;
            }
            break;

        case 4:
            if (!sequenceWaiting) {
                stepper4.moveTo(joint4);
                sequenceWaiting = true;
            }
            if (!stepper4.isRunning()) {
                sequenceStep++;
                sequenceWaiting = false;
            }
            break;

        case 5:
            if (!sequenceWaiting) {
                stepper5.moveTo(joint5);
                sequenceWaiting = true;
            }
            if (!stepper5.isRunning()) {
                jointSequenceInProgress = false;
                sequenceStep = 0;
                sequenceWaiting = false;
            }
            break;
    }
}

void runAutoMode() {
    if (!autoModeInProgress) {
        if (movingToA) {
            stepper1.moveTo(waypointA.j1);
            stepper2.moveTo(waypointA.j2);
            stepper3.moveTo(waypointA.j3);
            stepper4.moveTo(waypointA.j4);
            stepper5.moveTo(waypointA.j5);
            stepper6.moveTo(waypointA.j1);
        } else {
            stepper1.moveTo(waypointB.j1);
            stepper2.moveTo(waypointB.j2);
            stepper3.moveTo(waypointB.j3);
            stepper4.moveTo(waypointB.j4);
            stepper5.moveTo(waypointB.j5);
            stepper6.moveTo(waypointB.j1);
        }
        autoModeInProgress = true;
    }

    if (autoModeInProgress &&
        !stepper1.isRunning() && !stepper2.isRunning() && !stepper3.isRunning() &&
        !stepper4.isRunning() && !stepper5.isRunning() && !stepper6.isRunning()) {
        autoModeInProgress = false;
        movingToA = !movingToA;  // Toggle next target
    }
}

void updateWaypointSettings() {
    if (WaypointSettingA) {
        waypointA.j1 = joint1;
        waypointA.j2 = joint2;
        waypointA.j3 = joint3;
        waypointA.j4 = joint4;
        waypointA.j5 = joint5;
    }
    if (WaypointSettingB) {
        waypointB.j1 = joint1;
        waypointB.j2 = joint2;
        waypointB.j3 = joint3;
        waypointB.j4 = joint4;
        waypointB.j5 = joint5;
    }
}

void runAutoSequence() {
    if (!run || autoSequenceInProgress) return;

    autoSequenceInProgress = true;
    autoSequenceStep = 1;
    autoSequenceWaiting = false;
    run = false;
}

void updateAutoSequence() {
    if (!autoSequenceInProgress) return;

    int target1 = movingToA ? waypointA.j1 : waypointB.j1;
    int target2 = movingToA ? waypointA.j2 : waypointB.j2;
    int target3 = movingToA ? waypointA.j3 : waypointB.j3;
    int target4 = movingToA ? waypointA.j4 : waypointB.j4;
    int target5 = movingToA ? waypointA.j5 : waypointB.j5;

    switch (autoSequenceStep) {
        case 1:
            if (!autoSequenceWaiting) {
                stepper1.moveTo(lround(target1 * J1GearRatio / degreesPerStep)); // Convert degrees to steps
                stepper6.moveTo(lround(target1 * J1GearRatio / degreesPerStep)); // Convert degrees to steps
                autoSequenceWaiting = true;
            }
            if (!stepper1.isRunning()) {
                autoSequenceStep++;
                autoSequenceWaiting = false;
            }
            break;
        case 2:
            if (!autoSequenceWaiting) {
                stepper2.moveTo(lround(target2 * J2GearRatio / degreesPerStep)); // Convert degrees to steps;
                autoSequenceWaiting = true;
            }
            if (!stepper2.isRunning()) {
                autoSequenceStep++;
                autoSequenceWaiting = false;
            }
            break;
        case 3:
            if (!autoSequenceWaiting) {
                stepper3.moveTo(lround(target3 * J3GearRatio / degreesPerStep)); // Convert degrees to steps
                autoSequenceWaiting = true;
            }
            if (!stepper3.isRunning()) {
                autoSequenceStep++;
                autoSequenceWaiting = false;
            }
            break;
        case 4:
            if (!autoSequenceWaiting) {
                stepper4.moveTo(lround(target4 * J4GearRatio / degreesPerStep)); // Convert degrees to steps
                autoSequenceWaiting = true;
            }
            if (!stepper4.isRunning()) {
                autoSequenceStep++;
                autoSequenceWaiting = false;
            }
            break;
        case 5:
            if (!autoSequenceWaiting) {
                stepper5.moveTo(lround(target5 * J5GearRatio / degreesPerStep)); // Convert degrees to steps
                autoSequenceWaiting = true;
            }
            if (!stepper5.isRunning()) {
                autoSequenceInProgress = false;
                autoSequenceStep = 0;
                autoSequenceWaiting = false;
                movingToA = !movingToA;  // toggle direction
            }
            break;
    }
}  

void Home(){
    stepper1.moveTo(0); // Convert degrees to steps
    stepper2.moveTo(0); // Convert degrees to steps
    stepper3.moveTo(0); // Convert degrees to steps
    stepper4.moveTo(0); // Convert degrees to steps
    stepper5.moveTo(0); // Convert degrees to steps
    stepper6.moveTo(0); // Convert degrees to steps
}

void safeSettingUpdate() {
    stepper1.moveTo(stepper1.currentPosition());
    stepper2.moveTo(stepper2.currentPosition());
    stepper3.moveTo(stepper3.currentPosition());
    stepper4.moveTo(stepper4.currentPosition());
    stepper5.moveTo(stepper5.currentPosition());
    stepper6.moveTo(stepper6.currentPosition());
}